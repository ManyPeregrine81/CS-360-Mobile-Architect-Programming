package com.example.projecttwouiloginbfr;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private EditText etItemName, etItemQuantity, etPhoneNumber;
    private Button btnAddItem, btnBackToLogin, btnSendSms;
    private RecyclerView recyclerViewInventory;
    private DatabaseHelper databaseHelper;
    private InventoryAdapter inventoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        databaseHelper = new DatabaseHelper(this);

        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQuantity);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnBackToLogin = findViewById(R.id.btnBackToLogin);
        btnSendSms = findViewById(R.id.btnSendSms);
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);

        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));
        loadInventoryList();

        btnAddItem.setOnClickListener(v -> {
            String name = etItemName.getText().toString().trim();
            String quantity = etItemQuantity.getText().toString().trim();

            if (name.isEmpty() || quantity.isEmpty()) {
                Toast.makeText(DashboardActivity.this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = databaseHelper.addInventoryItem(name, quantity);
            if (success) {
                Toast.makeText(DashboardActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                etItemName.setText("");
                etItemQuantity.setText("");
                loadInventoryList();
            } else {
                Toast.makeText(DashboardActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle Send SMS Notification click
        btnSendSms.setOnClickListener(v -> {
            String phoneNumber = etPhoneNumber.getText().toString().trim();
            if (phoneNumber.isEmpty()) {
                Toast.makeText(DashboardActivity.this, "Please enter a phone number for SMS alert", Toast.LENGTH_SHORT).show();
                return;
            }
            checkAndSendSms(phoneNumber);
        });

        // Handle Back to Login button click
        btnBackToLogin.setOnClickListener(v -> finish());
    }

    private void checkAndSendSms(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSmsMessage(phoneNumber);
        } else {
            // Request SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void sendSmsMessage(String phoneNumber) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Alert: Congratulations on reaching your goal weight!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS notification sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
                String phoneNumber = etPhoneNumber.getText().toString().trim();
                if (!phoneNumber.isEmpty()) {
                    sendSmsMessage(phoneNumber);
                }
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications will not be sent.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loadInventoryList() {
        List<InventoryItem> items = databaseHelper.getAllInventoryItems();
        if (inventoryAdapter == null) {
            inventoryAdapter = new InventoryAdapter(items, id -> {
                databaseHelper.deleteInventoryItem(id);
                Toast.makeText(DashboardActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadInventoryList();
            });
            recyclerViewInventory.setAdapter(inventoryAdapter);
        } else {
            inventoryAdapter.updateList(items);
        }
    }
}
