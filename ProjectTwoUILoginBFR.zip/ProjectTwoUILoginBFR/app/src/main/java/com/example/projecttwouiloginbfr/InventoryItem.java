package com.example.projecttwouiloginbfr;

public class InventoryItem {
    private long id;
    private String name;
    private String quantity;

    public InventoryItem(long id, String name, String quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return quantity;
    }
}
