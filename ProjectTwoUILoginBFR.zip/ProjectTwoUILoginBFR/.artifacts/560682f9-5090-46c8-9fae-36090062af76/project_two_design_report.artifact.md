# SNHU CS-360 Project Two: Design & Architecture Report

## Overview
This document outlines the architectural design, user interface visual hierarchy, database schema, and automated SMS notification workflows implemented for **Project Two** (`ProjectTwoUILoginBFR`).

---

## 1. System Architecture & Database Schema

The application follows an **MVVM/MVC-inspired structure** utilizing SQLite (`SQLiteOpenHelper`) for local data persistence and standard Android Activities with Intents for navigation.

### Entity-Relationship Diagram (Database)
```mermaid
erDiagram
    USERS {
        integer id PK
        text username UK
        text password
    }
    INVENTORY {
        integer id PK
        text name
        text quantity
    }
```

- **`users` table**: Stores account credentials (`username` and `password`) to authenticate user sessions and handle account creation.
- **`inventory` table**: Stores user data/items (`name` and `quantity`) displayed in the data grid.

---

## 2. User Journey & Screen Transitions

The app features two primary screens with seamless, consistent navigation:

```mermaid
graph TD
    A[MainActivity: Login / Register Screen] -->|Successful Login or 'Go to Database'| B[DashboardActivity: Inventory Grid & SMS Alerts]
    B -->|Click 'Back to Login'| A
    A -->|Click 'Create Account'| C[Database Check & Insert User]
    C -->|Success Toast| A
```

---

## 3. SMS Notification & Runtime Permission Workflow

Automated system notifications focus exclusively on **Goal Weight** updates, adhering strictly to runtime permission best practices.

```mermaid
sequenceDiagram
    participant User
    participant DashboardActivity
    participant System as Android OS / SmsManager

    User->>DashboardActivity: Click 'Send Goal Weight SMS Alert'
    DashboardActivity->>DashboardActivity: Check SEND_SMS Permission
    alt Permission Granted
        DashboardActivity->>System: sendTextMessage(phoneNumber, message)
        System-->>User: Deliver Goal Weight SMS Alert
        System-->>DashboardActivity: Send Success Toast
    else Permission Denied
        DashboardActivity->>System: ActivityCompat.requestPermissions()
        System-->>User: Show Permission Dialog
        User->>System: Deny Permission
        DashboardActivity-->>User: Display Toast (App functions normally without SMS)
    end

    Note over DashboardActivity, System: If permission is denied, app continues to function normally overall.
```

---

## 4. UI Visual Hierarchy & Grouping

Both screens are organized into clear visual groups with an intuitive focus order:

### Login Screen (`activity_main.xml`)
1. **Welcome Title**: Establishes context (`tvTitle`).
2. **Input Fields**: Username (`etUsername`) and Password (`etPassword`).
3. **Primary Actions**: Login (`btnLogin`) and Account Creation (`btnRegister`).
4. **Secondary Navigation**: Go to Database View (`btnGoToDashboard`).

### Dashboard Screen (`activity_dashboard.xml`)
1. **Header Group**: Dashboard Title & Back to Login button.
2. **Add Inventory Section**: Item name, quantity inputs, and Add button.
3. **SMS Notification Section**: Phone number input and Goal Weight notification button.
4. **Data Grid Section**: Column headers and scrollable `RecyclerView` (`recyclerViewInventory`).

---

## 5. Summary of Key Code Components

- **[MainActivity.java](file:///C:/Users/g77ri/AndroidStudioProjects/ProjectTwoUILoginBFR/app/src/main/java/com/example/projecttwouiloginbfr/MainActivity.java)**: Handles authentication, account creation checks, and view transitions.
- **[DashboardActivity.java](file:///C:/Users/g77ri/AndroidStudioProjects/ProjectTwoUILoginBFR/app/src/main/java/com/example/projecttwouiloginbfr/DashboardActivity.java)**: Manages database CRUD operations for the grid, runtime permissions, and SMS goal weight alerts.
- **[DatabaseHelper.java](file:///C:/Users/g77ri/AndroidStudioProjects/ProjectTwoUILoginBFR/app/src/main/java/com/example/projecttwouiloginbfr/DatabaseHelper.java)**: SQLite implementation handling both user credentials and inventory records.
- **[AndroidManifest.xml](file:///C:/Users/g77ri/AndroidStudioProjects/ProjectTwoUILoginBFR/app/src/main/AndroidManifest.xml)**: Declares telephony features and `SEND_SMS` permissions.
